let username = document.getElementById("username");
let dob = document.getElementById("dob");
let pwd = document.getElementById("pwd");
let pwdagain = document.getElementById("pwdagain");

function validate(){
    if(username.value==""||dob.value==""||pwd.value==""||pwdagain.value==""){
        alert("Fields cannot be empty");
        return false;
    }
    else{
        return true;
        alert("Validation is proper");
    }
}